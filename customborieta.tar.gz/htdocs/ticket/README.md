Ticket module
=============


An issue tracker that provides a delicate balance between simplicity and power and complete integration with the other modules.
Offer your customers an easy to use interface to report and follow status of their issue. Manage your issues from
your backoffice.
 

(c) The development of this module has been initiated by the company <a href="https://librethic.io">Libr&thic</a> and is now part of Dolibarr ERP CRM core.
