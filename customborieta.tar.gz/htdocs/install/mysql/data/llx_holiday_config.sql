INSERT INTO llx_holiday_config (name ,value) VALUES ('lastUpdate', NULL);
